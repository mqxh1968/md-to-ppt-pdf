#!/usr/bin/env python3
"""
CSS Enhancer for HTML reports — html-ppt-skill inspired styles
Injects Navy + Gold design tokens into an existing HTML file
"""
import sys, os

ENHANCE_CSS = '''<style>
:root {
    --primary: #0D2137;
    --gold: #D4AF37;
    --accent: #2E86AB;
    --bg-light: #F5F3EE;
    --text-dark: #1A1A2E;
    --text-muted: #6B7280;
    --card-bg: #FFFFFF;
}
body { background: #F0EDE6; font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif; }
h1 { color: var(--primary) !important; border-bottom: 3px solid var(--gold) !important; padding-bottom: 12px !important; font-weight: 700 !important; }
h2 { color: var(--primary) !important; border-left: 4px solid var(--gold) !important; padding-left: 16px !important; font-weight: 600 !important; }
h3 { color: var(--accent) !important; font-weight: 600 !important; }
table { border-collapse: collapse !important; width: 100% !important; box-shadow: 0 2px 8px rgba(0,0,0,0.06); border-radius: 6px; overflow: hidden; }
table thead th { background: var(--primary) !important; color: #FFF !important; padding: 10px 14px !important; font-weight: 600 !important; text-align: left !important; }
table tbody td { padding: 9px 14px !important; border-bottom: 1px solid #E5E0D8 !important; }
table tbody tr:nth-child(even) { background: #FAF8F5 !important; }
table tbody tr:nth-child(odd) { background: #FFF !important; }
blockquote { border-left: 4px solid var(--gold) !important; background: #F8F6F0 !important; padding: 16px 20px !important; border-radius: 0 6px 6px 0; }
strong { color: var(--primary) !important; }
code { background: #F0EDE6 !important; color: var(--accent) !important; padding: 2px 6px !important; border-radius: 3px; }
a { color: var(--accent) !important; }
hr { border: none !important; height: 2px !important; background: linear-gradient(to right, var(--gold), transparent) !important; }
@media print { body { background: #FFF !important; } @page { size: A4; margin: 20mm 18mm; } }
</style>\n'''

def main():
    if len(sys.argv) < 2:
        print("usage: inject_css.py <html-file>")
        sys.exit(1)

    html_path = sys.argv[1]
    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    if '</head>' in html:
        html = html.replace('</head>', ENHANCE_CSS + '\n</head>')
    elif '<head>' in html:
        html = html.replace('<head>', '<head>\n' + ENHANCE_CSS)
    else:
        html = ENHANCE_CSS + '\n' + html

    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f"CSS injected into {html_path}")

if __name__ == '__main__':
    main()
