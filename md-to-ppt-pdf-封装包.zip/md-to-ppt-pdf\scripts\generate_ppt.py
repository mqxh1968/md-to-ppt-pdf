#!/usr/bin/env python3
"""
html-ppt-skill style PPT generator
基于 html-ppt-skill 设计理念：Token 驱动设计系统 + 主题配色 + 布局模板
用 python-pptx 直接生成精美 PPTX
"""
import os
from pptx import Presentation
from pptx.util import Inches, Pt, Emu, Cm
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn

# ============================================================
# Token 驱动设计系统 (类似 html-ppt-skill 的 CSS 变量)
# ============================================================
class DesignTokens:
    # 主题: Corporate Pitch (Navy + Gold) - 文旅投资风
    COLOR_PRIMARY    = RGBColor(0x0D, 0x21, 0x37)   # Navy Blue 主色
    COLOR_SECONDARY  = RGBColor(0xD4, 0xAF, 0x37)   # Gold 强调色
    COLOR_ACCENT     = RGBColor(0x2E, 0x86, 0xAB)   # Teal 数据色
    COLOR_BG_DARK    = RGBColor(0x0A, 0x18, 0x2A)   # 深色背景
    COLOR_BG_LIGHT   = RGBColor(0xF5, 0xF3, 0xEE)   # 暖白背景
    COLOR_TEXT_DARK  = RGBColor(0x1A, 0x1A, 0x2E)   # 深色文字
    COLOR_TEXT_LIGHT = RGBColor(0xE8, 0xE4, 0xD9)   # 浅色文字
    COLOR_TEXT_MUTED = RGBColor(0x6B, 0x72, 0x80)   # 灰色文字
    COLOR_GOLD_GRAD_START = RGBColor(0xE8, 0xC5, 0x47)
    COLOR_GOLD_GRAD_END   = RGBColor(0xB8, 0x8A, 0x1E)
    COLOR_CARD_BG    = RGBColor(0xFF, 0xFF, 0xFF)   # 卡片白
    COLOR_DIVIDER    = RGBColor(0xD4, 0xAF, 0x37)   # 分割线金色
    COLOR_TABLE_HEADER = RGBColor(0x0D, 0x21, 0x37)
    COLOR_TABLE_STRIPE = RGBColor(0xF0, 0xEE, 0xE8)
    
    FONT_CN = 'Microsoft YaHei'
    FONT_EN = 'Segoe UI'
    
    SLIDE_W = Inches(13.333)  # 16:9
    SLIDE_H = Inches(7.5)

T = DesignTokens()

# ============================================================
# 工具函数
# ============================================================
def set_slide_bg(slide, color):
    """设置幻灯片纯色背景"""
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color

def add_textbox(slide, left, top, width, height, text, font_size=18,
                color=None, bold=False, align=PP_ALIGN.LEFT, font_name=None,
                line_spacing=1.3, anchor=MSO_ANCHOR.TOP):
    """添加文本框"""
    color = color or T.COLOR_TEXT_DARK
    font_name = font_name or T.FONT_CN
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True
    tf.auto_size = None
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.font.name = font_name
    p.alignment = align
    p.line_spacing = Pt(font_size * line_spacing)
    # 设置东亚字体
    for run in p.runs:
        rPr = run._r.get_or_add_rPr()
        rPr.set(qn('a:eaTypeface'), font_name)
    return txBox

def add_multiline_textbox(slide, left, top, width, height, lines,
                          default_size=16, default_color=None, line_spacing=1.5):
    """添加多行文本框，lines 为 [(text, font_size, color, bold), ...]"""
    default_color = default_color or T.COLOR_TEXT_DARK
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True
    tf.auto_size = None
    
    for i, line_data in enumerate(lines):
        if isinstance(line_data, str):
            text, size, color, bold = line_data, default_size, default_color, False
        else:
            text = line_data[0]
            size = line_data[1] if len(line_data) > 1 else default_size
            color = line_data[2] if len(line_data) > 2 else default_color
            bold = line_data[3] if len(line_data) > 3 else False
        
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        
        p.text = text
        p.font.size = Pt(size)
        p.font.color.rgb = color
        p.font.bold = bold
        p.font.name = T.FONT_CN
        p.line_spacing = Pt(size * line_spacing)
        for run in p.runs:
            rPr = run._r.get_or_add_rPr()
            rPr.set(qn('a:eaTypeface'), T.FONT_CN)
    
    return txBox

def add_shape_rect(slide, left, top, width, height, fill_color=None, border_color=None, border_width=0, corner_radius=None):
    """添加矩形"""
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if corner_radius else MSO_SHAPE.RECTANGLE,
                                    Inches(left), Inches(top), Inches(width), Inches(height))
    shape.line.fill.background()
    if fill_color:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill_color
    else:
        shape.fill.background()
    if border_color:
        shape.line.color.rgb = border_color
        shape.line.width = Pt(border_width)
    return shape

def add_gold_divider(slide, left, top, width=3):
    """添加金色分割线"""
    shape = add_shape_rect(slide, left, top, width, 0.03, T.COLOR_DIVIDER)

def add_page_number(slide, num, total=12):
    """添加页码"""
    add_textbox(slide, 12.0, 7.1, 1.0, 0.3, f"{num:02d} / {total:02d}",
                font_size=9, color=T.COLOR_TEXT_MUTED, align=PP_ALIGN.RIGHT)

def add_footer_bar(slide, page_num, title_text=""):
    """添加底部装饰条"""
    # 细线
    add_shape_rect(slide, 0.5, 6.95, 12.333, 0.01, T.COLOR_DIVIDER)
    # 页码
    add_textbox(slide, 0.5, 7.0, 5.0, 0.4, title_text, font_size=9, color=T.COLOR_TEXT_MUTED)
    add_page_number(slide, page_num)

# ============================================================
# 页面模板 (类似 html-ppt-skill 的 31 种布局)
# ============================================================

def slide_cover(prs):
    """P1: 封面 - 仿 pitch-deck-vc 主题"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
    set_slide_bg(slide, T.COLOR_PRIMARY)
    
    # 大面积金色装饰块
    add_shape_rect(slide, 0, 0, 13.333, 0.15, T.COLOR_SECONDARY)
    add_shape_rect(slide, 0, 7.35, 13.333, 0.15, T.COLOR_SECONDARY)
    
    # 左侧金色竖条
    add_shape_rect(slide, 0.8, 1.5, 0.06, 4.2, T.COLOR_SECONDARY)
    
    # 主标题
    add_textbox(slide, 1.2, 1.5, 10.5, 1.2,
                "文旅知识付费赛道", font_size=48, color=T.COLOR_TEXT_LIGHT, bold=True)
    add_textbox(slide, 1.2, 2.7, 10.5, 0.8,
                "研究报告", font_size=44, color=T.COLOR_TEXT_LIGHT, bold=True)
    
    # 副标题
    add_textbox(slide, 1.2, 3.6, 10.5, 0.5,
                "市场规模 · 竞争格局 · 变现模式 · 差异化机会 · 90天行动蓝图",
                font_size=18, color=T.COLOR_SECONDARY)
    
    # 金色分割线
    add_shape_rect(slide, 1.2, 4.3, 3.0, 0.03, T.COLOR_SECONDARY)
    
    # 底部信息
    add_textbox(slide, 1.2, 4.7, 5.0, 0.4,
                "2026年6月  |  深度调研与策略输出",
                font_size=14, color=T.COLOR_TEXT_MUTED)
    
    # 右侧装饰 - 大圆
    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(9.5), Inches(2.5), Inches(3.0), Inches(3.0))
    circle.fill.background()
    circle.line.color.rgb = T.COLOR_SECONDARY
    circle.line.width = Pt(2)
    
    # 装饰小圆
    for x, y in [(11.2, 3.2), (10.5, 4.3), (11.8, 4.8)]:
        c = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(0.4), Inches(0.4))
        c.fill.solid()
        c.fill.fore_color.rgb = T.COLOR_GOLD_GRAD_START
        c.line.fill.background()

def slide_toc(prs):
    """P2: 目录"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_BG_LIGHT)
    
    # 标题区
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_textbox(slide, 0.8, 0.5, 5.0, 0.6, "目录 CONTENTS", font_size=28, color=T.COLOR_PRIMARY, bold=True)
    add_gold_divider(slide, 0.8, 1.15, 2.0)
    
    items = [
        ("01", "市场规模与用户画像", "2800亿知识付费市场，文旅赛道处于早期红利期"),
        ("02", "竞争格局与平台生态", "攻略红海 vs 专业蓝海，六大平台能力矩阵"),
        ("03", "变现模式与商业化路径", "课程→社群→咨询三层漏斗，从0到1实操路线"),
        ("04", "差异化机会识别", "你的独特优势：真实项目 + 行业资源"),
        ("05", "渠道策略与执行计划", "90天冷启动，公私域组合打法"),
        ("06", "风险与对策", "内容同质化、平台依赖、政策合规三线防范"),
    ]
    
    for i, (num, title, desc) in enumerate(items):
        y = 1.8 + i * 0.85
        # 序号圆圈
        badge = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(1.0), Inches(y), Inches(0.5), Inches(0.5))
        badge.fill.solid()
        badge.fill.fore_color.rgb = T.COLOR_PRIMARY
        badge.line.fill.background()
        tf = badge.text_frame
        tf.word_wrap = False
        p = tf.paragraphs[0]
        p.text = num
        p.font.size = Pt(13)
        p.font.color.rgb = T.COLOR_SECONDARY
        p.font.bold = True
        p.font.name = T.FONT_EN
        p.alignment = PP_ALIGN.CENTER
        
        add_textbox(slide, 1.8, y - 0.05, 5.0, 0.35, title, font_size=18, color=T.COLOR_PRIMARY, bold=True)
        add_textbox(slide, 1.8, y + 0.3, 9.5, 0.3, desc, font_size=12, color=T.COLOR_TEXT_MUTED)
    
    add_page_number(slide, 2)

def slide_section(prs, num, title, subtitle=""):
    """章节分隔页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_PRIMARY)
    
    add_shape_rect(slide, 0, 3.0, 13.333, 0.06, T.COLOR_SECONDARY)
    add_shape_rect(slide, 0, 4.5, 13.333, 0.06, T.COLOR_SECONDARY)
    
    add_textbox(slide, 1.5, 2.4, 10.0, 0.6, f"PART {num:02d}", font_size=18, color=T.COLOR_SECONDARY, bold=True)
    add_textbox(slide, 1.5, 3.2, 10.0, 1.0, title, font_size=36, color=T.COLOR_TEXT_LIGHT, bold=True)
    if subtitle:
        add_textbox(slide, 1.5, 4.7, 10.0, 0.5, subtitle, font_size=14, color=T.COLOR_TEXT_MUTED)

def slide_3_conclusions(prs):
    """P3: 核心结论 - 三栏布局"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_BG_LIGHT)
    
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_textbox(slide, 0.8, 0.5, 5.0, 0.5, "核心结论", font_size=28, color=T.COLOR_PRIMARY, bold=True)
    add_gold_divider(slide, 0.8, 1.05, 2.0)
    
    conclusions = [
        ("🔵 赛道判断", "文旅知识付费存在专业内容真空", 
         "攻略内容严重饱和，但投资决策、景区运营、文旅商业模式等专业内容几乎零供给。2025 年知识付费市场达 2800 亿，文旅垂直渗透率不足 3%，窗口期有限。"),
        ("🟡 变现路径", "三层漏斗：课程 → 社群 → 咨询", 
         "课程（99-199元）起量、社群（199元/月）蓄水、咨询（3000-5000元/次）高客单价，LTV 约 3-8 万元/每批用户。一人公司模式，90 天可完成从 0 到 1。"),
        ("🟢 你的优势", "真实项目 = 不可替代的护城河", 
         "塘栖古镇、南昌人民公园、南昌记忆 1927 等真实操盘经验，形成竞品无法复制的案例壁垒。B 端企业培训和政府咨询是高价值延伸方向。"),
    ]
    
    for i, (tag, title, desc) in enumerate(conclusions):
        x = 0.6 + i * 4.1
        # 卡片背景
        card = add_shape_rect(slide, x, 1.5, 3.8, 5.0, T.COLOR_CARD_BG, corner_radius=0.1)
        card.shadow.inherit = False
        
        # 标签
        add_textbox(slide, x + 0.3, 1.7, 3.2, 0.35, tag, font_size=12, color=T.COLOR_SECONDARY, bold=True)
        # 标题
        add_textbox(slide, x + 0.3, 2.15, 3.2, 0.8, title, font_size=18, color=T.COLOR_PRIMARY, bold=True)
        # 分割线
        add_shape_rect(slide, x + 0.3, 2.85, 1.0, 0.02, T.COLOR_SECONDARY)
        # 描述
        add_textbox(slide, x + 0.3, 3.1, 3.2, 3.0, desc, font_size=12, color=T.COLOR_TEXT_MUTED, line_spacing=1.8)
    
    add_page_number(slide, 3)

def slide_market_size(prs):
    """P4: 市场规模与用户画像"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_BG_LIGHT)
    
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_textbox(slide, 0.8, 0.5, 5.0, 0.5, "市场规模与用户画像", font_size=28, color=T.COLOR_PRIMARY, bold=True)
    
    # 左侧：关键数据
    metrics = [
        ("2800亿", "2025年中国知识付费\n市场规模"),
        ("5.8亿", "知识付费用户\n总规模"),
        ("< 3%", "文旅垂直赛道\n渗透率"),
        ("72%", "25-40岁用户\n占比"),
    ]
    
    for i, (num, label) in enumerate(metrics):
        x = 0.6 + i * 3.1
        card = add_shape_rect(slide, x, 1.5, 2.8, 2.0, T.COLOR_CARD_BG, corner_radius=0.08)
        add_textbox(slide, x + 0.2, 1.6, 2.4, 0.8, num, font_size=40, color=T.COLOR_PRIMARY, bold=True, align=PP_ALIGN.CENTER)
        add_textbox(slide, x + 0.2, 2.4, 2.4, 0.8, label, font_size=11, color=T.COLOR_TEXT_MUTED, align=PP_ALIGN.CENTER)
    
    # 底部用户画像表格
    table_data = [
        ["用户分层", "核心需求", "付费意愿", "触达渠道"],
        ["景区投资者/运营者", "项目评估方法、投资回报测算", "高（500-5000元/课程）", "知乎、公众号、行业社群"],
        ["文旅从业者/中层管理", "运营实操、案例分析、工具方法", "中（99-499元/课程）", "抖音、小红书、视频号"],
        ["文旅爱好者/创业新人", "入门认知、趋势了解、案例启发", "低（9.9-99元/课程）", "小红书、B站、短视频"],
    ]
    
    y_start = 4.0
    row_h = 0.65
    col_widths = [2.2, 3.5, 3.2, 3.3]
    
    for r, row in enumerate(table_data):
        y = y_start + r * row_h
        x_acc = 0.6
        for c, cell in enumerate(row):
            bg = T.COLOR_TABLE_HEADER if r == 0 else (T.COLOR_CARD_BG if r % 2 == 0 else T.COLOR_TABLE_STRIPE)
            txt_color = T.COLOR_TEXT_LIGHT if r == 0 else T.COLOR_TEXT_DARK
            shape = add_shape_rect(slide, x_acc, y, col_widths[c], row_h, bg)
            add_textbox(slide, x_acc + 0.15, y + 0.1, col_widths[c] - 0.3, row_h - 0.2,
                       cell, font_size=10 if r > 0 else 11, color=txt_color, bold=(r == 0),
                       align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
            x_acc += col_widths[c]
    
    add_page_number(slide, 4)

def slide_competitive(prs):
    """P5: 竞争格局 - 双栏对比"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_BG_LIGHT)
    
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_textbox(slide, 0.8, 0.5, 5.0, 0.5, "竞争格局：攻略红海 vs 专业蓝海", font_size=28, color=T.COLOR_PRIMARY, bold=True)
    
    # 左侧红海
    add_shape_rect(slide, 0.6, 1.4, 5.8, 0.4, RGBColor(0xC0, 0x39, 0x2B))
    add_textbox(slide, 0.8, 1.42, 5.0, 0.35, "🔴 攻略红海 — 已饱和", font_size=16, color=RGBColor(0xFF, 0xFF, 0xFF), bold=True)
    
    red_items = [
        "旅游攻略、景点推荐、打卡指南 → 内容同质化严重",
        "头部博主垄断流量，新入局者获客成本极高",
        "变现依赖广告/带货，知识付费转化率低",
        "平台算法偏好娱乐化内容，深度内容难获推荐",
    ]
    for i, item in enumerate(red_items):
        add_textbox(slide, 1.0, 2.0 + i * 0.7, 5.2, 0.6, f"• {item}", font_size=12, color=T.COLOR_TEXT_DARK)
    
    # 右侧蓝海
    add_shape_rect(slide, 6.9, 1.4, 5.8, 0.4, RGBColor(0x27, 0xAE, 0x60))
    add_textbox(slide, 7.1, 1.42, 5.0, 0.35, "🟢 专业蓝海 — 待开发", font_size=16, color=RGBColor(0xFF, 0xFF, 0xFF), bold=True)
    
    blue_items = [
        "景区投资决策、运营管理 → 内容供给近乎为零",
        "高客单价（500-5000元），用户精准、竞争少",
        "B端企业培训、政府咨询 → 高价值延伸方向",
        "专业壁垒高，真实项目经验 = 不可替代的护城河",
    ]
    for i, item in enumerate(blue_items):
        add_textbox(slide, 7.3, 2.0 + i * 0.7, 5.2, 0.6, f"• {item}", font_size=12, color=T.COLOR_TEXT_DARK)
    
    # 底部总结
    add_shape_rect(slide, 0.6, 5.2, 12.1, 1.2, T.COLOR_PRIMARY, corner_radius=0.05)
    add_textbox(slide, 1.0, 5.35, 11.3, 0.9,
                '💡 策略建议：主攻「景区投资决策 + 文旅商业运营」垂直赛道，用真实案例建立专业壁垒。\n避开攻略红海，不做泛流量，专注高价值精准用户。',
                font_size=13, color=T.COLOR_TEXT_LIGHT, line_spacing=1.6)
    
    add_page_number(slide, 5)

def slide_platform(prs):
    """P6: 平台生态对比"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_BG_LIGHT)
    
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_textbox(slide, 0.8, 0.5, 6.0, 0.5, "六大平台能力矩阵", font_size=28, color=T.COLOR_PRIMARY, bold=True)
    
    platforms = [
        ("知乎", "深度内容", "⭐⭐⭐⭐⭐", "中高知人群", "⭐⭐⭐⭐", "专栏+Live+咨询", "专业内容首选"),
        ("得到", "体系课程", "⭐⭐⭐⭐", "职场人群", "⭐⭐⭐⭐⭐", "课程+训练营", "高客单价精品课"),
        ("知识星球", "付费社群", "⭐⭐⭐⭐⭐", "忠实粉丝", "⭐⭐⭐⭐", "年费+内容沉淀", "私域核心阵地"),
        ("小鹅通", "课程工具", "⭐⭐⭐⭐", "全量用户", "⭐⭐⭐", "SaaS服务费", "课程交付载体"),
        ("抖音/视频号", "流量获客", "⭐⭐⭐⭐⭐", "泛人群", "⭐⭐", "直播+短视频引流", "公域获客前端"),
        ("小红书", "种草内容", "⭐⭐⭐⭐", "年轻女性", "⭐⭐", "图文+短视频", "品牌认知建立"),
    ]
    
    headers = ["平台", "内容定位", "内容匹配", "目标用户", "付费能力", "变现方式", "推荐用法"]
    col_w = [1.4, 1.4, 1.4, 1.4, 1.4, 2.0, 2.0]
    
    for c, header in enumerate(headers):
        x = sum(col_w[:c]) + 0.4
        shape = add_shape_rect(slide, x, 1.3, col_w[c], 0.45, T.COLOR_PRIMARY)
        add_textbox(slide, x + 0.1, 1.33, col_w[c] - 0.2, 0.4, header,
                   font_size=10, color=T.COLOR_TEXT_LIGHT, bold=True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    
    for r, row in enumerate(platforms):
        y = 1.8 + r * 0.75
        bg_color = T.COLOR_CARD_BG if r % 2 == 0 else T.COLOR_TABLE_STRIPE
        for c, cell in enumerate(row):
            x = sum(col_w[:c]) + 0.4
            add_shape_rect(slide, x, y, col_w[c], 0.7, bg_color)
            add_textbox(slide, x + 0.1, y + 0.05, col_w[c] - 0.2, 0.6, cell,
                       font_size=9, color=T.COLOR_TEXT_DARK, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    
    # 总结
    add_shape_rect(slide, 0.6, 6.55, 12.1, 0.6, T.COLOR_PRIMARY, corner_radius=0.05)
    add_textbox(slide, 0.9, 6.58, 11.5, 0.55,
                '推荐组合：知乎（深度内容）+ 知识星球（付费社群）+ 小鹅通（课程交付）+ 抖音/视频号（流量获客）',
                font_size=12, color=T.COLOR_TEXT_LIGHT, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    
    add_page_number(slide, 6)

def slide_monetization(prs):
    """P7: 变现模式 - 三层漏斗"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_BG_LIGHT)
    
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_textbox(slide, 0.8, 0.5, 5.0, 0.5, "变现模式：三层漏斗", font_size=28, color=T.COLOR_PRIMARY, bold=True)
    
    # 三层漏斗可视化
    layers = [
        ("第一层：课程产品", "定价 99-199 元", "获客入口 · 建立信任 · 筛选付费用户", T.COLOR_ACCENT, 7.5),
        ("第二层：付费社群", "定价 199 元/月", "深度互动 · 案例拆解 · 持续复购", T.COLOR_PRIMARY, 5.5),
        ("第三层：一对一咨询", "定价 3000-5000 元/次", "高客单价 · 个性化服务 · 价值最大化", T.COLOR_SECONDARY, 3.5),
    ]
    
    for i, (title, price, desc, color, w) in enumerate(layers):
        x = (13.333 - w) / 2
        y = 1.5 + i * 1.55
        # 背景层
        add_shape_rect(slide, x, y, w, 1.3, color, corner_radius=0.1)
        add_textbox(slide, x + 0.4, y + 0.15, w - 0.8, 0.4, title,
                   font_size=20, color=RGBColor(0xFF, 0xFF, 0xFF), bold=True)
        add_textbox(slide, x + 0.4, y + 0.5, w - 0.8, 0.3, price,
                   font_size=14, color=RGBColor(0xCC, 0xCC, 0xCC))
        add_textbox(slide, x + 0.4, y + 0.8, w - 0.8, 0.35, desc,
                   font_size=11, color=RGBColor(0xFF, 0xFF, 0xFF), line_spacing=1.3)
    
    # 右侧数据卡
    add_shape_rect(slide, 9.8, 1.5, 3.0, 4.8, T.COLOR_CARD_BG, corner_radius=0.08)
    add_textbox(slide, 10.0, 1.7, 2.6, 0.3, "📊 预期数据", font_size=14, color=T.COLOR_PRIMARY, bold=True)
    
    data_items = [
        ("转化率", "课程浏览 → 购买：3-5%"),
        ("", "课程用户 → 社群：15-20%"),
        ("", "社群用户 → 咨询：5-10%"),
        ("客单价", "课程：¥99-199"),
        ("", "社群：¥199/月"),
        ("", "咨询：¥3000-5000/次"),
        ("LTV", "首批100人 → 3-8万"),
        ("冷启动", "90天可完成从0到1"),
    ]
    
    y_pos = 2.2
    for label, value in data_items:
        if label:
            add_textbox(slide, 10.0, y_pos, 2.6, 0.25, label, font_size=10, color=T.COLOR_PRIMARY, bold=True)
            y_pos += 0.22
        add_textbox(slide, 10.15, y_pos, 2.45, 0.25, value, font_size=9, color=T.COLOR_TEXT_MUTED)
        y_pos += 0.3
    
    add_page_number(slide, 7)

def slide_differentiation(prs):
    """P8: 差异化机会"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_BG_LIGHT)
    
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_textbox(slide, 0.8, 0.5, 5.0, 0.5, "你的差异化优势", font_size=28, color=T.COLOR_PRIMARY, bold=True)
    
    advantages = [
        ("🏛️", "真实项目经验", "塘栖古镇 · 南昌人民公园 · 南昌记忆1927\n三大项目形成完整的文旅操盘案例库"),
        ("📊", "投资决策方法论", "从项目评估到投资回报测算\n形成可复制的分析框架与指标体系"),
        ("🎯", "精准资源网络", "政府关系 · 行业人脉 · 供应链资源\nB端企业培训和高价值咨询的天然入口"),
        ("🔒", "不可替代的护城河", "真实案例 + 行业认知 + 资源网络\n三个维度建立竞品无法短期复制的壁垒"),
    ]
    
    for i, (icon, title, desc) in enumerate(advantages):
        x = 0.5 + i * 3.15
        # 卡片
        card = add_shape_rect(slide, x, 1.4, 2.9, 4.8, T.COLOR_CARD_BG, corner_radius=0.08)
        # 图标区
        icon_bg = add_shape_rect(slide, x + 0.3, 1.6, 2.3, 1.2, T.COLOR_PRIMARY, corner_radius=0.06)
        add_textbox(slide, x + 0.3, 1.7, 2.3, 1.0, icon,
                   font_size=36, color=T.COLOR_TEXT_LIGHT, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        # 标题
        add_textbox(slide, x + 0.3, 3.0, 2.3, 0.4, title,
                   font_size=16, color=T.COLOR_PRIMARY, bold=True, align=PP_ALIGN.CENTER)
        # 分割线
        add_shape_rect(slide, x + 1.0, 3.45, 0.9, 0.02, T.COLOR_SECONDARY)
        # 描述
        add_textbox(slide, x + 0.3, 3.6, 2.3, 2.0, desc,
                   font_size=10, color=T.COLOR_TEXT_MUTED, align=PP_ALIGN.CENTER, line_spacing=1.7)
    
    add_page_number(slide, 8)

def slide_90day_plan(prs):
    """P9: 90天行动计划"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_BG_LIGHT)
    
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_textbox(slide, 0.8, 0.5, 5.0, 0.5, "90天冷启动计划", font_size=28, color=T.COLOR_PRIMARY, bold=True)
    
    phases = [
        ("第 1-30 天", "内容基建期", "• 确定 MVP 选题：文旅景区投资决策实战课\n• 搭建知乎专栏 + 知识星球\n• 发布 10 篇深度文章，建立专业认知\n• 设计课程大纲和定价策略", T.COLOR_ACCENT),
        ("第 31-60 天", "获客验证期", "• 上线第一期课程（定价 199，首月 99）\n• 知乎导流 + 朋友圈裂变\n• 积累首批 50-100 名付费用户\n• 收集反馈，迭代课程内容", T.COLOR_PRIMARY),
        ("第 61-90 天", "规模化增长", "• 知识星球社群运营（199元/月）\n• 启动一对一咨询（3000-5000元/次）\n• 拓展 B 端企业培训业务\n• 建立内容更新的 SOP", T.COLOR_SECONDARY),
    ]
    
    for i, (time, title, tasks, color) in enumerate(phases):
        y = 1.5 + i * 1.85
        # 时间线连接点
        dot = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(0.8), Inches(y + 0.15), Inches(0.25), Inches(0.25))
        dot.fill.solid()
        dot.fill.fore_color.rgb = color
        dot.line.fill.background()
        
        if i < 2:
            add_shape_rect(slide, 0.9, y + 0.4, 0.04, 1.3, RGBColor(0xDD, 0xDD, 0xDD))
        
        # 时间标签
        tag = add_shape_rect(slide, 1.3, y, 1.6, 0.35, color, corner_radius=0.04)
        add_textbox(slide, 1.3, y + 0.02, 1.6, 0.3, time,
                   font_size=11, color=RGBColor(0xFF, 0xFF, 0xFF), bold=True, align=PP_ALIGN.CENTER)
        
        # 标题
        add_textbox(slide, 3.2, y - 0.05, 3.0, 0.4, title,
                   font_size=18, color=T.COLOR_PRIMARY, bold=True)
        
        # 任务列表
        add_textbox(slide, 3.2, y + 0.35, 9.0, 1.2, tasks,
                   font_size=11, color=T.COLOR_TEXT_DARK, line_spacing=1.6)
    
    add_page_number(slide, 9)

def slide_risk(prs):
    """P10: 风险与对策"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_BG_LIGHT)
    
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_textbox(slide, 0.8, 0.5, 5.0, 0.5, "风险与对策", font_size=28, color=T.COLOR_PRIMARY, bold=True)
    
    risks = [
        ("⚠️ 内容同质化风险", "中", "随着赛道热度上升，竞品模仿增多", "持续输出原创案例，建立方法论壁垒；用真实项目数据说话，竞品无法复制"),
        ("⚠️ 平台依赖风险", "中高", "单一平台算法变化可能导致流量断崖", "多平台布局（知乎+星球+视频号），私域沉淀为核心；降低对公域流量的依赖"),
        ("⚠️ 变现周期风险", "中低", "从免费内容到付费转化的时间窗口", "定价策略灵活（阶梯定价+限时优惠），前期以获客为核心目标，不急于盈利"),
        ("⚠️ 政策合规风险", "低", "文旅行业涉及土地、规划等敏感议题", "课程内容聚焦商业运营，避开政策评价；必要时咨询法律顾问"),
    ]
    
    headers = ["风险项", "等级", "风险描述", "应对策略"]
    col_w = [2.2, 1.0, 3.5, 5.5]
    
    for c, header in enumerate(headers):
        x = sum(col_w[:c]) + 0.5
        add_shape_rect(slide, x, 1.3, col_w[c], 0.45, T.COLOR_PRIMARY)
        add_textbox(slide, x + 0.1, 1.33, col_w[c] - 0.2, 0.4, header,
                   font_size=11, color=T.COLOR_TEXT_LIGHT, bold=True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    
    for r, (risk, level, desc, strategy) in enumerate(risks):
        y = 1.8 + r * 1.25
        row_data = [risk, level, desc, strategy]
        bg = T.COLOR_CARD_BG if r % 2 == 0 else T.COLOR_TABLE_STRIPE
        
        level_color = T.COLOR_TEXT_DARK
        if "高" in level:
            level_color = RGBColor(0xC0, 0x39, 0x2B)
        elif "中" in level:
            level_color = RGBColor(0xD4, 0xAF, 0x37)
        else:
            level_color = RGBColor(0x27, 0xAE, 0x60)
        
        for c, cell in enumerate(row_data):
            x = sum(col_w[:c]) + 0.5
            add_shape_rect(slide, x, y, col_w[c], 1.2, bg)
            txt_color = level_color if c == 1 else T.COLOR_TEXT_DARK
            bld = (c == 1)
            fc = 10 if c >= 2 else 11
            add_textbox(slide, x + 0.15, y + 0.1, col_w[c] - 0.3, 1.0, cell,
                       font_size=fc, color=txt_color, bold=bld, anchor=MSO_ANCHOR.MIDDLE)
    
    add_page_number(slide, 10)

def slide_mvp(prs):
    """P11: MVP 推荐"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_PRIMARY)
    
    add_shape_rect(slide, 0, 0, 13.333, 0.1, T.COLOR_SECONDARY)
    add_shape_rect(slide, 0, 7.4, 13.333, 0.1, T.COLOR_SECONDARY)
    
    # 中央大卡片
    card = add_shape_rect(slide, 1.5, 1.2, 10.333, 5.3, T.COLOR_CARD_BG, corner_radius=0.12)
    
    add_textbox(slide, 2.0, 1.5, 9.333, 0.5, "🏆 推荐 MVP 选题", font_size=24, color=T.COLOR_PRIMARY, bold=True, align=PP_ALIGN.CENTER)
    add_gold_divider(slide, 5.5, 2.1, 2.333)
    
    add_textbox(slide, 2.0, 2.4, 9.333, 0.8,
                "《文旅景区投资决策实战课：从项目评估到投资回报》",
                font_size=28, color=T.COLOR_SECONDARY, bold=True, align=PP_ALIGN.CENTER)
    
    details = [
        "📌 定价：199 元（首月特价 99 元）",
        "📌 形式：知乎专栏（引流）+ 小鹅通（交付）+ 知识星球（社群）",
        "📌 内容：10 讲核心课程 + 3 个真实案例拆解 + 1 套投资决策工具模板",
        "📌 目标：首月招募 50 名种子用户，验证 PMF",
    ]
    
    y = 3.4
    for detail in details:
        add_textbox(slide, 2.5, y, 8.333, 0.4, detail, font_size=14, color=T.COLOR_TEXT_DARK, align=PP_ALIGN.CENTER)
        y += 0.5
    
    # CTA
    cta_bg = add_shape_rect(slide, 3.5, 5.7, 6.333, 0.55, T.COLOR_SECONDARY, corner_radius=0.06)
    add_textbox(slide, 3.5, 5.72, 6.333, 0.5, "现在就行动 — 抓住文旅知识付费的窗口期",
               font_size=16, color=T.COLOR_PRIMARY, bold=True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

def slide_thanks(prs):
    """P12: 致谢"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, T.COLOR_PRIMARY)
    
    add_shape_rect(slide, 0, 3.15, 13.333, 0.06, T.COLOR_SECONDARY)
    add_shape_rect(slide, 0, 4.35, 13.333, 0.06, T.COLOR_SECONDARY)
    
    add_textbox(slide, 0, 2.5, 13.333, 0.6, "THANK YOU",
               font_size=48, color=T.COLOR_SECONDARY, bold=True, align=PP_ALIGN.CENTER)
    add_textbox(slide, 0, 3.35, 13.333, 0.8, "谢谢",
               font_size=42, color=T.COLOR_TEXT_LIGHT, bold=True, align=PP_ALIGN.CENTER)
    
    add_textbox(slide, 0, 4.6, 13.333, 0.5,
                "文旅知识付费赛道研究报告  |  2026年6月",
                font_size=16, color=T.COLOR_TEXT_MUTED, align=PP_ALIGN.CENTER)
    
    # 装饰
    for x in [3.5, 5.5, 7.5, 9.5]:
        dot = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(5.5), Inches(0.15), Inches(0.15))
        dot.fill.solid()
        dot.fill.fore_color.rgb = T.COLOR_SECONDARY
        dot.line.fill.background()


# ============================================================
# 主流程
# ============================================================
def main():
    OUTPUT_DIR = "E:/桌面/AI-Workstation/Workbuddy/成果"
    OUTPUT_FILE = os.path.join(OUTPUT_DIR, "文旅知识付费赛道研究报告-精美PPT-20260609.pptx")
    
    prs = Presentation()
    prs.slide_width = T.SLIDE_W
    prs.slide_height = T.SLIDE_H
    
    # 批量生成 12 页
    slide_cover(prs)           # P1
    slide_toc(prs)             # P2
    slide_3_conclusions(prs)   # P3
    slide_market_size(prs)     # P4
    slide_competitive(prs)     # P5
    slide_platform(prs)        # P6
    slide_monetization(prs)    # P7
    slide_differentiation(prs) # P8
    slide_90day_plan(prs)      # P9
    slide_risk(prs)            # P10
    slide_mvp(prs)             # P11
    slide_thanks(prs)          # P12
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    prs.save(OUTPUT_FILE)
    print(f"✅ PPT generated: {OUTPUT_FILE}")
    print(f"   Slides: 12")
    print(f"   Theme: Corporate Pitch (Navy + Gold)")

if __name__ == "__main__":
    main()
